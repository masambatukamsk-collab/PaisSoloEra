# PaisSoloEra Web — Hosting Ready

Versi ini sudah disiapkan untuk hosting Node.js/Docker dan **tidak membutuhkan Termux**.

## Cara paling mudah: Render

1. Buat akun di Render.
2. Upload project ini ke GitHub sebagai repository.
3. Di Render pilih **New > Web Service** lalu pilih repository tersebut.
4. Render akan membaca `render.yaml`/Dockerfile.
5. Isi environment variables:
   - `TELEGRAM_BOT_TOKEN` = token bot dari BotFather
   - `OWNER_ID` = numeric Telegram ID kamu
   - `ADMIN_USER` = username dashboard
   - `ADMIN_PASSWORD` = password dashboard
6. Deploy.
7. Setelah selesai, Render memberi URL `https://...onrender.com`.

## Catatan penting

Dashboard dan bot berjalan dari server hosting. Browser HP hanya perlu membuka URL hasil deploy.

`data/templates.json` masih berupa penyimpanan file lokal. Pada hosting yang filesystem-nya ephemeral, perubahan template dapat hilang ketika service diredeploy/restart. Untuk versi produksi, sebaiknya nanti dipindahkan ke database (misalnya PostgreSQL/Supabase).

Versi ini belum mengirim pesan WhatsApp. Fokusnya adalah dashboard + editor template + Telegram bot.
