# PaisSoloEra Web v1

Dashboard web + Telegram bot starter.

## Jalankan
1. npm install
2. cp .env.example .env
3. isi TELEGRAM_BOT_TOKEN, OWNER_ID, ADMIN_USER, ADMIN_PASSWORD
4. npm start
5. buka http://localhost:3000

Dashboard menggunakan HTTP Basic Auth. Template disimpan di data/templates.json. Placeholder: {TARGET}.

Versi pertama belum mengaktifkan pengiriman WhatsApp; fokusnya dashboard dan Telegram.
